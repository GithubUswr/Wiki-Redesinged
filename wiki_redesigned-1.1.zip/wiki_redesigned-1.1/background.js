const baseURL = {
    server1 : "https://projectredesign.herokuapp.com/wiki/",
    server2 : "https://projectredesign2.herokuapp.com/wiki/",
    checkVersionBackup : "https://projectredesign2.herokuapp.com/versionCheckLink"
};

function set(toset) {
    chrome.storage.local.set(toset);    
}
function get(toget,callback) {
    chrome.storage.local.get(toget,function(res){
      callback(res);
    });
}
function curl(path){
    return chrome.runtime.getURL(path);
}
chrome.runtime.onInstalled.addListener(function(){
    // cleaning local storage
    chrome.storage.local.clear();

    // setting necessary items to local storage
    set({ 
        setting: true, 
        theme: "useImageViewer",
        last_checked: null,
        version: 1.1,
        checkVersion: "https://dl.dropbox.com/s/p7y6xnq82czdih5/update_info.json?dl=0",
        extra_script:null,
        menu_html:null
    });
    ResourceFiles('start',curl('css/minified/start.css'));
    ResourceFiles('HTML',curl('innerHTML/innerHTML.txt'));
    ResourceFiles('litecss',curl('css/minified/wikiNew.css'));
    ResourceFiles('darkcss',curl('css/minified/wikiNewDark.css'));
    ResourceFiles('fontcss',curl('css/minified/fonts.css'));
    ResourceFiles('fontDcss',curl('css/minified/fontD.css'));

    // checking for update files on install
    fetchLatestFiles();
});

function ResourceFiles(name,path){
    xhttpGet(path,function(data){
        set({[name]:data});
    });
}

chrome.runtime.onStartup.addListener(function(){
    fetchLatestFiles();
})

chrome.runtime.onMessage.addListener(function(message){
    if(message === "checkForUpdate"){
        fetchLatestFiles();
    }
})

function xhttpGet(link,callback,type){
    type ? null : type = 'text';
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if(this.readyState === 4){
            if (this.status === 200) {
                callback(this.response);
            }
            else{
                callback(false);
            }
        }
    };
    xhttp.responseType = type;
    xhttp.open("GET", link, true);
    xhttp.send();
}

function fetchLatestFiles(){
    console.log('checking for latest files');
    get(['version','last_checked','checkVersion'],function(res){
        var current_time = new Date().getHours();
        var current_ver = res.version;
        var checkLink = res.checkVersion;
        if(current_time !== res.last_checked){
            set({last_checked:current_time});
            checkLatestVersion(checkLink,current_ver);
        }
        else{
            console.log('checked recently, no update avaliable')
        }
    });

    function checkLatestVersion(link,current){
        xhttpGet(link,function(res){
            if(res){
                if(res.wiki > current){
                    getUpdate(current);   
                }
                else{
                    console.log('already latest')
                }
            }
            else{
                console.log('server error, will try again later');
                xhttpGet(baseURL.checkVersionBackup,function(res){
                    if(res){
                        set({checkVersion:res.link})
                    }
                },'json');
            }
        },'json')
    }

    function getUpdate(current_ver){
        function toDo(res){
            var main = res.main;
            var maindark = res.maindark;
            var font = res.font;
            var fontdark = res.fontdark;
            var start = res.start;
            var script = res.script;
            var html = res.html;
            var menu = res.menu;
            
            if(main.toUpdate) set({litecss:main.data});
            if(maindark.toUpdate) set({darkcss:maindark.data});
            if(font.toUpdate) set({fontcss:font.data});
            if(fontdark.toUpdate) set({fontDcss:fontdark.data});
            if(start.toUpdate) set({start:start.data});
            if(html.toUpdate) set({HTML:html.data});
            script.toUpdate ? set({extra_script:script.data}) : set({extra_script:null});
            menu.toUpdate ? set({menu_html:menu.data}) : set({menu_html:null});
            
            console.log('files updated to latest version');
        }

        xhttpGet(baseURL.server1+"getUpdate", function(res){
            if(res){
                if(res.version > current_ver){
                    set({version:res.version});
                    toDo(res);
                }
                else console.log('already latest');
            }
            else{
                xhttpGet(baseURL.server2+"getUpdate", function(res){
                    if(res){
                        if(res.version > current_ver){
                            set({version:res.version});
                            toDo(res);
                        }
                        else console.log('already latest');
                    }
                    else{
                        console.log('server error, will try again later');
                    }
                },'json')
            }
        },'json')
    }
}
