body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let voyageCss = newElement({e:'link',rel:'stylesheet'});
    voyageCss.href = curl("css/sisterProjects/wikivoyage.css");
    document.head.appendChild(voyageCss);
}