body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let wikibooksCss = newElement({e:'link',rel:'stylesheet'});
    wikibooksCss.href = curl("css/sisterProjects/wikibooks.css");
    document.head.appendChild(wikibooksCss);
}