body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let wiktionaryCss = newElement({e:'link',rel:'stylesheet'});
    wiktionaryCss.href = curl("css/sisterProjects/wiktionary.css");
    document.head.appendChild(wiktionaryCss);
}