body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let wikicommonsCss = newElement({e:'link',rel:'stylesheet'});
    wikicommonsCss.href = curl("css/sisterProjects/wikicommons.css");
    document.head.appendChild(wikicommonsCss);
}