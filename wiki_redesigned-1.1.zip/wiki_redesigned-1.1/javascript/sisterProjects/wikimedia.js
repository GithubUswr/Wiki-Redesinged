body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let mediaCss = newElement({e:'link',rel:'stylesheet'});
    mediaCss.href = curl("css/sisterProjects/wikimedia.css");
    document.head.appendChild(mediaCss);
}