body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let wikinewsCss = newElement({e:'link',rel:'stylesheet'});
    wikinewsCss.href = curl("css/sisterProjects/wikinews.css");
    document.head.appendChild(wikinewsCss);
}