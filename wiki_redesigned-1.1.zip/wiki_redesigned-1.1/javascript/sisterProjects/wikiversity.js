body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let wikiversityCss = newElement({e:'link',rel:'stylesheet'});
    wikiversityCss.href = curl("css/sisterProjects/wikiversity.css");
    document.head.appendChild(wikiversityCss);
}