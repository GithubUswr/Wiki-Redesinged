body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let mediaWikiCss = newElement({e:'link',rel:'stylesheet'});
    mediaWikiCss.href = curl("css/sisterProjects/mediawiki.css");
    document.head.appendChild(mediaWikiCss);
}