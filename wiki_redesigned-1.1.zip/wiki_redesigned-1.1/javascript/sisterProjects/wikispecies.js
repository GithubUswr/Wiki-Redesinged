body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let wikispeciesCss = newElement({e:'link',rel:'stylesheet'});
    wikispeciesCss.href = curl("css/sisterProjects/wikispecies.css");
    document.head.appendChild(wikispeciesCss);
}