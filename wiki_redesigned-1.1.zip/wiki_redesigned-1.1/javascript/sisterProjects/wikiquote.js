body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let wikiquoteCss = newElement({e:'link',rel:'stylesheet'});
    wikiquoteCss.href = curl("css/sisterProjects/wikiquote.css");
    document.head.appendChild(wikiquoteCss);
    let a = document.getElementById('mf-header');
    if(a){
        document.getElementsByClassName('mw-parser-output')[0].classList.add('titlePage');
    }
}