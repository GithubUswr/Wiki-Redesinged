body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let wikidataCss = newElement({e:'link',rel:'stylesheet'});
    wikidataCss.href = curl("css/sisterProjects/wikidata.css");
    document.head.appendChild(wikidataCss);
}