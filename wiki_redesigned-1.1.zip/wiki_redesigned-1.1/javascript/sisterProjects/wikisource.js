body = document.body;
function checkStatus() {
    if (body.wrStatus !== undefined) {
        if (body.wrStatus) {
            toDo()
        }
    } else {
        setTimeout(function () {
            checkStatus()
        }, 10)
    }
}
checkStatus();

function toDo(){
    let wikisourceCss = newElement({e:'link',rel:'stylesheet'});
    wikisourceCss.href = curl("css/sisterProjects/wikisource.css");
    document.head.appendChild(wikisourceCss);
}