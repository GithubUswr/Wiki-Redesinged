function onDomLoad(callback){
    if(document.readyState !== "loading") callback()
    else window.addEventListener('DOMContentLoaded',callback)
}

// html component addition
chrome.storage.local.get("menu_html",function(res){
    if(res.menu_html !== null){
        onDomLoad(function(){
            var options = document.getElementsByClassName('options')[0];
            options.insertAdjacentHTML('afterend',res.menu_html);
        })
    }
});

// fetching extention info
var extStatus;
chrome.storage.local.get(["setting"],function(response){
    extStatus = response.setting;
    if(extStatus) document.body.id="extensionEnabled";
    else document.body.id="extensionDisabled";
});


// funtion to toggle extention
function toggleExtension(){
    if(extStatus){
        chrome.storage.local.set({setting:false});
        chrome.browserAction.setIcon({path:"../images/icon_disable.png"});
        document.body.id="extensionDisabled";
        extStatus = false;
    }
    else{
        chrome.storage.local.set({setting:true});
        chrome.browserAction.setIcon({path:"../images/icon.png"});
        document.body.id="extensionEnabled";
        extStatus = true;
    }
}

// to-do after DOM loaded
onDomLoad(function(){
    var toggleExtBtn = document.getElementById('setting');
    toggleExtBtn.onclick = toggleExtension;

    var contribute = document.getElementById("contribute").firstElementChild;
    contribute.onclick = function(){
        window.open("https://www.paypal.com/paypalme/HritikMaster");
    }
})